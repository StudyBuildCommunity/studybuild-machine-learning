# Data

## Source

**Default of Credit Card Clients Dataset** — UCI Machine Learning Repository / I-Cheng Yeh (2009), collected from a bank in Taiwan (April–September 2005).

- UCI page: https://archive.ics.uci.edu/dataset/350/default+of+credit+card+clients
- File expected here: `default of credit card clients.xls`
- 30,000 rows, 24 raw columns (23 features + 1 target), header on row 2 of the Excel file (`pd.read_excel(path, header=1)`).

This raw file is **not tracked in git** due to size (~5.4 MB) and licensing — download it from the UCI link above and place it in this folder with the exact filename used by the notebook.

## Target variable

`default payment next month` — binary, 1 = client defaulted on payment the following month, 0 = did not.

- Class distribution: 23,364 (77.88%) non-default vs. 6,636 (22.12%) default — moderately imbalanced.

## Fields

| Column | Description |
|---|---|
| `ID` | Row identifier (dropped before modeling) |
| `LIMIT_BAL` | Credit limit (NT dollars), includes individual and family/supplementary credit |
| `SEX` | 1 = male, 2 = female |
| `EDUCATION` | 1 = graduate school, 2 = university, 3 = high school, 4 = others |
| `MARRIAGE` | 1 = married, 2 = single, 3 = others |
| `AGE` | Age in years |
| `PAY_0, PAY_2..PAY_6` | Repayment status for the 6 most recent months (`PAY_0` = most recent; renamed `PAY_1` in this project for consistent numbering). Documented codes: −1 = paid duly, 1–8 = months delayed. |
| `BILL_AMT1..BILL_AMT6` | Bill statement amount, most recent to oldest month |
| `PAY_AMT1..PAY_AMT6` | Amount paid, most recent to oldest month |

## Undocumented / anomalous values found and handled

These are **not part of the official UCI variable documentation** and are cleaned in Q1/Q4 of the notebook before any modeling:

- **`EDUCATION`**: raw values include `0`, `5`, `6` (14 / 280 / 51 rows) with no documented meaning. Remapped to `4` ("others").
- **`MARRIAGE`**: raw value `0` (54 rows) is undocumented. Remapped to `3` ("others").
- **`PAY_1..PAY_6`**: raw values include `-2` and `0` in addition to the documented `-1` and `1`–`8`. These are widely interpreted in practice as "no consumption" (`-2`) and "revolving credit / paid minimum" (`0`), but this is **not officially documented by UCI** and is called out explicitly rather than silently assumed. Left as-is (not remapped) since they are legitimate, high-frequency values, not encoding errors — but documented here so downstream users are aware.
- **`BILL_AMT1..BILL_AMT6`**: contain a nontrivial number of negative values (590–688 rows per column) — these plausibly represent credit balances / overpayments rather than data errors, and are left as-is.

## Column rename

`PAY_0` → `PAY_1` for consistent `PAY_1..PAY_6` naming across the whole project (`PAY_1` = most recent month, `PAY_6` = oldest). Applied once, early, before any analysis.
