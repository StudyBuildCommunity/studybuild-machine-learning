# Credit Default Risk — Management Summary

**Audience:** Risk / credit management. **Purpose:** what to do with this model's output, what it can support, and what it cannot.

## Bottom line

A baseline Logistic Regression model, trained on 24 months of Taiwanese credit card client data (30,000 clients, 2005), can meaningfully separate higher-risk from lower-risk clients — the model's High-risk group has a default rate roughly **6× higher** than its Low-risk group. The single strongest, simplest, most reliable signal is **how recently and severely a client has fallen behind on payments**, not their education, marital status, or other demographic traits.

This model is suitable today as an **experimental tool for prioritizing manual credit review** — not for automated accept/reject decisions, and not yet for production deployment. See "What's needed before deployment" below.

## Who needs closer review

**Primary segment: clients 2+ months delinquent in their most recent billing cycle (`PAY_1 ≥ 2`).**

| Segment | Clients | Default rate | vs. portfolio average |
|---|---:|---:|---:|
| Not significantly delinquent (`PAY_1 < 2`) | 26,870 (89.6%) | 16.6% | 0.75× |
| **2+ months delinquent (`PAY_1 ≥ 2`)** | **3,130 (10.4%)** | **69.6%** | **3.14×** |

This one segment — just over 1 in 10 clients — carries close to 3× the portfolio's baseline default rate. It is also the largest single coefficient among all standardized (comparable) numeric predictors in the model, confirmed independently by exploratory correlation, effect-size, and univariate-AUC analysis (Cohen's d = 0.83, AUC = 0.69 — the strongest of any variable).

**Credit limit does not protect against this risk.** Splitting the delinquent segment by credit-limit quartile shows default rates staying in a tight 68.6%–70.7% band across every quartile — clients with high credit limits who are already delinquent are just as likely to default as those with low limits. Credit limit should not be used to deprioritize review of a delinquent client.

**Recommended action:** direct manual review / outreach capacity at this ~3,130-client segment first. The three-tier Low / Medium / High risk grouping (`outputs/risk_groups.csv`) operationalizes this prioritization across the full portfolio:

| Risk group | Predicted probability | Clients | % of portfolio | Default prevalence |
|---|---|---:|---:|---:|
| Low | ≤ 0.20 | 15,947 | 53.2% | 12.5% |
| Medium | 0.20 – 0.50 | 11,707 | 39.0% | 25.4% |
| High | > 0.50 | 2,346 | 7.8% | 71.5% |

Cutoffs were chosen by comparing several candidate pairs on a held-out validation set (not the final test set), selecting the pair with the cleanest monotonic separation and no group under 5% of the population — not by eyeballing the test set. Full detail in `notebooks/credit_risk_analysis.ipynb`, Q7.

## What this model cannot establish

- **Causation.** Every finding here is a statistical association, not a causal claim. A delayed payment being associated with default does not mean it *causes* default — both could stem from a common factor (e.g., an income shock). This applies especially to demographic variables: the model's use of `SEX` and `MARRIAGE` reflects statistical patterns in this historical sample, not evidence that gender or marital status *causes* default risk, and neither should be used to justify discriminatory credit decisions.
- **A formal credit rating.** This is a training-grade risk-segmentation prototype, not a regulated or validated credit-scoring system, and should not replace formal, governed credit assessment processes.
- **Generalization to today or to other markets.** The data is from Taiwanese clients in 2005. Economic conditions, interest rates, and lending norms have changed since; the model has never been validated on data outside this time/geography.
- **Certainty for any individual client.** The model outputs probabilities, not certainties. Even in the High-risk group (71.5% default prevalence), roughly 1 in 4 clients will not default — group membership alone should not drive a decision without individual review.
- **Which threshold is "correct."** Two plausible thresholds (0.30 and 0.50) were both found to be statistically stable across validation and test splits, but they produce very different operating points (0.30: catches more defaulters, flags more good clients; 0.50: the reverse). Statistics cannot say which is "right" — that depends on the relative cost the business assigns to a missed defaulter (false negative) vs. a wrongly flagged good client (false positive).

## What's needed before real deployment

1. **Out-of-time validation** — test the model on more recent data to confirm it still holds under current economic conditions.
2. **A documented FN/FP cost ratio from Risk/Finance** — needed to select and defend a production threshold; this cannot come from the model itself.
3. **A fairness audit** — the model currently includes `SEX`, `MARRIAGE`, and `EDUCATION`. Error rates, precision, and recall should be compared across demographic subgroups before deployment to rule out unintended discrimination.
4. **Supplementary data** — employment history, verified income, or external credit bureau scores would likely add signal beyond what's in this dataset.
5. **Ongoing monitoring** — periodic tracking of actual default rates within each risk group to detect model or population drift over time.
6. **Legal/regulatory review** — confirm that using demographic variables (sex, marital status) in credit decisions complies with applicable anti-discrimination and lending regulations in the deployment jurisdiction; they may need to be removed from the final production model even if retained here for analysis.

---
*Full technical analysis, all supporting figures, and question-by-question detail: `notebooks/credit_risk_analysis.ipynb`. Risk-scored portfolio export: `outputs/risk_groups.csv`.*
