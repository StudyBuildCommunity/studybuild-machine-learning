"""
Reusable pipeline pieces for the credit default risk project.

This module factors out the cleaning, preprocessing, and baseline-model
logic that appears repeatedly across the notebook (Q1, Q4-Q10), so it can
be imported instead of copy-pasted if this project grows beyond a single
notebook. The notebook itself remains self-contained and does not import
this file -- it is provided for reuse in scripts, tests, or a future API.

Usage:
    from src.model import load_and_clean, build_preprocessor, build_logreg_pipeline

    df = load_and_clean("data/default of credit card clients.xls")
    X, y = df.drop(columns=[TARGET]), df[TARGET]
    pipeline = build_logreg_pipeline(X, random_state=42)
    pipeline.fit(X_train, y_train)
"""

from __future__ import annotations

import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

TARGET = "default payment next month"
CATEGORICAL_COLS = ["SEX", "EDUCATION", "MARRIAGE"]
RANDOM_SEED = 42


def load_and_clean(xls_path: str) -> pd.DataFrame:
    """Load the raw UCI Excel file and apply the project's cleaning rules.

    - Remaps undocumented EDUCATION codes (0, 5, 6) to 4 ("others").
    - Remaps undocumented MARRIAGE code (0) to 3 ("others").
    - Renames PAY_0 -> PAY_1 for consistent PAY_1..PAY_6 naming.
    - Drops the ID column.

    See data/README.md for why each of these choices was made.
    """
    data = pd.read_excel(xls_path, header=1)
    df = data.copy()
    df["EDUCATION"] = df["EDUCATION"].replace({0: 4, 5: 4, 6: 4})
    df["MARRIAGE"] = df["MARRIAGE"].replace({0: 3})
    if "PAY_0" in df.columns:
        df = df.rename(columns={"PAY_0": "PAY_1"})
    if "ID" in df.columns:
        df = df.drop("ID", axis=1)
    return df


def get_feature_columns(X: pd.DataFrame) -> tuple[list[str], list[str]]:
    """Split feature columns into (numeric_cols, categorical_cols)."""
    categorical_cols = [c for c in CATEGORICAL_COLS if c in X.columns]
    numeric_cols = [c for c in X.columns if c not in categorical_cols]
    return numeric_cols, categorical_cols


def build_preprocessor(X: pd.DataFrame, verbose_feature_names_out: bool = False) -> ColumnTransformer:
    """Build the standard preprocessing pipeline used throughout the project.

    Numeric features are standardized (StandardScaler); categorical features
    are one-hot encoded with the first category dropped as baseline. This
    ColumnTransformer is meant to be fit ONLY on training data (inside a
    Pipeline.fit call) to avoid leakage -- never fit it on the full dataset
    before splitting.
    """
    numeric_cols, categorical_cols = get_feature_columns(X)
    return ColumnTransformer(
        transformers=[
            ("num", StandardScaler(), numeric_cols),
            ("cat", OneHotEncoder(drop="first", handle_unknown="ignore"), categorical_cols),
        ],
        verbose_feature_names_out=verbose_feature_names_out,
    )


def build_logreg_pipeline(X: pd.DataFrame, random_state: int = RANDOM_SEED) -> Pipeline:
    """Build the baseline Logistic Regression pipeline (preprocessing + model)."""
    preprocessor = build_preprocessor(X)
    return Pipeline([
        ("preprocess", preprocessor),
        ("model", LogisticRegression(max_iter=1000, random_state=random_state)),
    ])


def get_standardized_and_onehot_coefficients(pipeline: Pipeline, categorical_cols: list[str] | None = None):
    """Return (numeric_coefs, onehot_coefs) as two separate pandas Series.

    IMPORTANT: numeric coefficients (StandardScaler'd, unit = per 1 SD) and
    one-hot coefficients (unscaled, unit = category vs. baseline) are NOT on
    the same scale and must never be ranked or compared in a single table by
    absolute magnitude. This function keeps them separate on purpose -- see
    Q4 and Q8 in the notebook for the full explanation and a worked example
    of the mistake this avoids.
    """
    if categorical_cols is None:
        categorical_cols = CATEGORICAL_COLS

    preprocessor = pipeline.named_steps["preprocess"]
    model = pipeline.named_steps["model"]

    onehot_names = list(
        preprocessor.named_transformers_["cat"].get_feature_names_out(categorical_cols)
    )
    feature_names = preprocessor.get_feature_names_out()
    coefs = pd.Series(model.coef_[0], index=feature_names)

    # feature_names may be prefixed (e.g. "num__PAY_1") depending on
    # verbose_feature_names_out; normalize before splitting.
    def strip_prefix(name: str) -> str:
        return name.split("__", 1)[1] if "__" in name else name

    coefs.index = [strip_prefix(n) for n in coefs.index]
    onehot_names_stripped = [strip_prefix(n) for n in onehot_names]

    onehot_coefs = coefs[onehot_names_stripped].sort_values(key=lambda s: s.abs(), ascending=False)
    numeric_coefs = coefs.drop(index=onehot_names_stripped).sort_values(key=lambda s: s.abs(), ascending=False)
    return numeric_coefs, onehot_coefs
